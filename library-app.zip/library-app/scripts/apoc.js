// left table static data
const libraries = [ // @todo fetch data from DB
  {
    name: 'Public Library',
    numberOfBooks: 2,   
  },
  {
    name: 'CIT Library',
    numberOfBooks: 1,     
  },
  {
    name: 'UC Library',
    numberOfBooks: 3, 
  },
  {
    name: 'CTS Library',
    numberOfBooks: 10,
  },
  {
    name: 'Banilad Library',
    numberOfBooks: 20,
  },
  {
    name: 'Lapu-lapu Library',
    numberOfBooks: 4,    
  },
  {
    name: 'Private Library',
    numberOfBooks: 6,    
  }
];

let table = '<table border="1">';
libraries.forEach((library) => {
  table += '<tr>' + '<td>' + library.name + '</td>';
  table += '<td>' + library.numberOfBooks + '</td>' + '</tr>';
});

document.getElementById('leftTable').innerHTML = table;

// center table static data
const relatedBooks = [
  {
    title: "Book Title 1",
    authorDatePublish: 'Author name, 02/24/2001',
    status: 'Available',
  },
  {
    title: "Book Title 2",
    authorDatePublish: 'Author name 2, 02/24/2001',
    status: 'Lost',
  },
  {
    title: "Book Title 3",
    authorDatePublish: 'Author name 3, 02/24/2001',
    status: 'Lost',
  },
  {
    title: "Book Title 4",
    authorDatePublish: 'Author name 4, 02/24/2001',
    status: 'Available',
  },
  {
    title: "Book Title 5",
    authorDatePublish: 'Author name 5, 02/24/2001',
    status: 'Available',
  },
  {
    title: "Book Title 6",
    authorDatePublish: 'Author name 6, 02/24/2001',
    status: 'Lost',
  },
];

var tbodyRef = document.getElementById('centerTable').getElementsByTagName('tbody')[0];

relatedBooks.forEach((book) => {
  var row = document.createElement("tr");
  var cell1 = document.createElement("td");
  var cell2 = document.createElement("td");
  var cell3 = document.createElement("td");
  cell1.innerHTML = book.title;
  cell2.innerHTML = book.authorDatePublish;
  cell3.innerHTML = book.status;
  row.appendChild(cell1);
  row.appendChild(cell2);
  row.appendChild(cell3);
  tbodyRef.appendChild(row);  
});

// last table static values
const bookBorrower = [
  {
    category: 'Student',
    noBooks: 10,
    noDays: 20,
  },
  {
    category: 'Faculty',
    noBooks: 30,
    noDays: 10,
  },
  {
    category: 'Staf',
    noBooks: 15,
    noDays: 30,
  }
];
var borrowersRef = document.getElementById('borrowersTable').getElementsByTagName('tbody')[0];
bookBorrower.forEach((borrower)=> {
  var row = document.createElement("tr");
  var cell1 = document.createElement("td");
  var cell2 = document.createElement("td");
  var cell3 = document.createElement("td");
  cell1.innerHTML = borrower.category;
  cell2.innerHTML = borrower.noBooks;
  cell3.innerHTML = borrower.noDays;
  row.appendChild(cell1);
  row.appendChild(cell2);
  row.appendChild(cell3);
  borrowersRef.appendChild(row);  
})